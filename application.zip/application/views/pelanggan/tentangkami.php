<div class="container">
  <div class="row">
    <div class="col-md-6 col-xl-3 d-flex justify-content-center">
      <img src="<?= base_url('asset/img/') ?>logo.png" width="250px" height="230px">
    </div>
    <div class="col-md-6 col-xl-9">
      <h1>Tentang Kami</h1>
      <p>Badriah Collection telah melayani Indonesia sejak tahun 1993.<br /><br />Badriah Collection adalah salah satu e-commerce di Indonesia. Badriah Collection banyak melakukan inovasi dalam menyediakan produk, khususnya di kategori busana muslim. <br /><br />Badriah Collection memulai bisnis dari tahun 2015 sebagai toko retail yang berada di kota Surabaya, Indonesia. Toko online Badriah Collection dibuat pada tahun 2020, di tengah situasi pandemi covid-19.                                                                                                                           <br />Rasakan pengalaman berbelanja online yang menyenangkan di Badriah Collection. Beli online berbagai macam busana di Badriah Collection prosesnya aman, cepat, dan mudah. <br /><br /><br /></p>
    </div>
  </div>
  <div class="container mt-1 mb-5">
    <div class="row mt-2">
      <div class="col-md-6">
        <div class="row ml-4 mt-2 mb-2">
          <div class="phone">
            <span class="number"><img src="<?= base_url('asset/') ?>img/whatsapp.png" width="40px"></span>
            <span>+628932-2323-232</span>
          </div>
          <div class="email ml-3">
            <span class="mail"><img src="<?= base_url('asset/') ?>img/email2.png" width="40px"></span>
            <span>abc@gmail.com</span>
          </div>
        </div>
        <div class="row ml-2 mb-2">
          <div class="Fb">
            <span><img src="<?= base_url('asset/') ?>img/fb.png" width="40px"></span>
            <span>abc@gmail.com</span>
          </div>
          <div class="IG ml-1">
            <span><img src="<?= base_url('asset/') ?>img/ig.png" width="40px"></span>
            <span>abc@gmail.com</span>
          </div>
          <div class="Twitter ml-1">
            <span><img src="<?= base_url('asset/') ?>img/twit.png" width="40px"></span>
            <span>abc@gmail.com</span>
          </div>
        </div>
      </div>
      <div class="col-md-6 mb-2"><img src="<?= base_url('asset/img/') ?>contact_us.png" width="360px" height="90px" class="ml-5" /></div>
    </div>
  </div>
  <div class="container">
    <div class="row">
      <div class="col-md-12 mb-5">
        <h1>Temukan kami</h1>
        <?php echo $map['html']; ?>
      </div>
    </div>
  </div>
</div>