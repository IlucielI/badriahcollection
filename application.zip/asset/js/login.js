var x = document.getElementById("login");
        var y = document.getElementById("daftar");
        var z = document.getElementById("btn");

        function daftar(){
            x.style.left = "-400px";
            y.style.left = "50px";
            z.style.left = "110px";
        }

        function login(){
            x.style.left = "50px";
            y.style.left = "400px";
            z.style.left = "0px";
        }

        
    